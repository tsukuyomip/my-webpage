Comic Forge の作品ファイルです。
